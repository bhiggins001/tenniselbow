# Daily Exercise Tracker

A responsive browser-based app for tracking daily wrist exercises.

## Features
- 4 exercise cards
- Exercise detail page
- Mark completed for today
- Monthly calendar view
- Monthly report summary
- Local browser storage
- Mobile and desktop responsive layout

## Files
- `index.html` - home page and dashboard
- `exercise.html` - exercise redirect page
- `styles.css` - responsive styling
- `app.js` - app logic and storage
- `manifest.json` - PWA metadata

## Add your JPG images
Place these files in `assets/`:
- `wrist-extensor-stretch.jpg`
- `wrist-flexor-stretch.jpg`
- `wrist-extension.jpg`
- `wrist-flexion.jpg`

## GitHub Pages deployment
1. Create a new GitHub repository.
2. Upload these files to the repo root.
3. Go to **Settings > Pages**.
4. Select the branch and root folder.
5. Save and wait for the URL to appear.

## Optional upgrades
- Add cloud sync with Firebase or Supabase.
- Add user login.
- Add PDF monthly reports.
- Add reminders and notifications.
