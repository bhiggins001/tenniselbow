const exercises = [
  { id:'wrist-extensor-stretch', title:'Wrist Extensor Stretch', image:'assets/wrist-extensor-stretch.jpg', summary:'Open the wrist extensor stretch page.' },
  { id:'wrist-flexor-stretch', title:'Wrist Flexor Stretch', image:'assets/wrist-flexor-stretch.jpg', summary:'Open the wrist flexor stretch page.' },
  { id:'wrist-extension', title:'Wrist Extension', image:'assets/wrist-extension.jpg', summary:'Open the wrist extension page.' },
  { id:'wrist-flexion', title:'Wrist Flexion', image:'assets/wrist-flexion.jpg', summary:'Open the wrist flexion page.' },
];

const key = 'exercise-tracker-v1';
const today = new Date();
const pad = n => String(n).padStart(2,'0');
const dateKey = d => `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}`;
const monthKey = d => `${d.getFullYear()}-${pad(d.getMonth()+1)}`;
const state = load();
let viewMonth = new Date(today.getFullYear(), today.getMonth(), 1);

function load(){ try { return JSON.parse(localStorage.getItem(key)) || { records: [] }; } catch { return { records: [] }; } }
function save(){ localStorage.setItem(key, JSON.stringify(state)); }
function recordFor(exId, day){ return state.records.find(r => r.exerciseId===exId && r.date===day); }
function isDone(exId, day){ return !!recordFor(exId, day)?.done; }
function setDone(exId, day, done){ const r = recordFor(exId, day); if(r) r.done = done; else state.records.push({ exerciseId: exId, date: day, done }); save(); renderAll(); }
function doneCountForDay(day){ return state.records.filter(r => r.date===day && r.done).length; }
function monthRecords(mKey){ return state.records.filter(r => r.date.startsWith(mKey) && r.done); }
function streak(){ let s = 0; let d = new Date(today); while(true){ const k = dateKey(d); const found = state.records.some(r => r.date===k && r.done); if(!found) break; s++; d.setDate(d.getDate()-1); } return s; }

function renderHome(){
  document.getElementById('todayLabel').textContent = today.toLocaleDateString(undefined, { weekday:'long', year:'numeric', month:'long', day:'numeric' });
  document.getElementById('doneToday').textContent = doneCountForDay(dateKey(today));
  document.getElementById('monthDone').textContent = monthRecords(monthKey(today)).length;
  document.getElementById('streak').textContent = streak();

  const grid = document.getElementById('exerciseGrid');
  const t = document.getElementById('exerciseTemplate');
  grid.innerHTML = '';
  exercises.forEach(ex => {
    const node = t.content.cloneNode(true);
    const a = node.querySelector('a');
    a.href = `exercise.html?id=${encodeURIComponent(ex.id)}`;
    a.querySelector('img').src = ex.image;
    a.querySelector('h3').textContent = ex.title;
    a.querySelector('p').textContent = ex.summary;
    grid.appendChild(node);
  });
}

function renderCalendar(){
  const title = document.getElementById('monthTitle');
  const reportTitle = document.getElementById('reportTitle');
  const cal = document.getElementById('calendar');
  const month = viewMonth.getMonth();
  const year = viewMonth.getFullYear();
  title.textContent = viewMonth.toLocaleDateString(undefined, { month:'long', year:'numeric' });
  reportTitle.textContent = title.textContent;
  cal.innerHTML = '';
  ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'].forEach(d => { const h = document.createElement('div'); h.className = 'day muted'; h.style.minHeight='auto'; h.innerHTML = `<strong>${d}</strong>`; cal.appendChild(h); });
  const first = new Date(year, month, 1);
  const start = first.getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const prevDays = new Date(year, month, 0).getDate();
  const totalCells = 42;
  for(let i=0;i<totalCells;i++){
    const cell = document.createElement('div');
    cell.className = 'day';
    let dayNum, cellDate, muted = false;
    if(i < start){ dayNum = prevDays - start + i + 1; cellDate = new Date(year, month - 1, dayNum); muted = true; }
    else if(i >= start + daysInMonth){ dayNum = i - (start + daysInMonth) + 1; cellDate = new Date(year, month + 1, dayNum); muted = true; }
    else { dayNum = i - start + 1; cellDate = new Date(year, month, dayNum); }
    const k = dateKey(cellDate);
    const count = doneCountForDay(k);
    const any = count > 0;
    cell.classList.toggle('muted', muted);
    cell.classList.toggle('done', count === exercises.length && !muted);
    cell.classList.toggle('partial', any && count < exercises.length && !muted);
    cell.innerHTML = `<span class='n'>${dayNum}</span><span class='count'>${any ? count + ' done' : ''}</span>`;
    cal.appendChild(cell);
  }

  const report = document.getElementById('reportList');
  const items = exercises.map(ex => {
    const done = state.records.filter(r => r.exerciseId===ex.id && r.date.startsWith(monthKey(viewMonth)) && r.done).length;
    return `<div class='report-item'><strong>${ex.title}</strong><span>${done} completed this month</span></div>`;
  }).join('');
  report.innerHTML = items;
}

function renderAll(){ renderHome(); renderCalendar(); }

function renderExercisePage(){
  const params = new URLSearchParams(location.search);
  const id = params.get('id');
  const ex = exercises.find(e => e.id === id) || exercises[0];
  document.title = ex.title + ' - Daily Exercise Tracker';
  const root = document.body;
  root.innerHTML = `
    <main class='exercise-page'>
      <div class='exercise-top'>
        <div>
          <a href='index.html' class='secondary' style='display:inline-block;margin-bottom:.75rem;padding:.7rem 1rem;border-radius:12px;background:#e9eef7;'>← Back</a>
          <h1>${ex.title}</h1>
          <p class='note'>Mark this exercise as completed for today.</p>
        </div>
        <div><strong>${dateKey(today)}</strong></div>
      </div>
      <section class='card exercise-panel'>
        <img src='${ex.image}' alt='${ex.title}' />
        <div>
          <h2>Completion</h2>
          <label class='check-box'>
            <input id='doneChk' type='checkbox' ${isDone(ex.id, dateKey(today)) ? 'checked' : ''} />
            <span>Completed today</span>
          </label>
          <p class='note'>Your selection is saved in the browser and used for the calendar and monthly report.</p>
        </div>
      </section>
    </main>`;
  document.getElementById('doneChk').addEventListener('change', e => setDone(ex.id, dateKey(today), e.target.checked));
}

function exportData(){
  const blob = new Blob([JSON.stringify(state, null, 2)], {type:'application/json'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a'); a.href = url; a.download = 'exercise-tracker-data.json'; a.click(); URL.revokeObjectURL(url);
}

function clearData(){ if(confirm('Clear all saved exercise data?')){ localStorage.removeItem(key); location.reload(); } }

if(location.pathname.endsWith('exercise.html')) renderExercisePage(); else { renderAll(); document.getElementById('prevMonth').onclick = () => { viewMonth = new Date(viewMonth.getFullYear(), viewMonth.getMonth()-1, 1); renderCalendar(); }; document.getElementById('nextMonth').onclick = () => { viewMonth = new Date(viewMonth.getFullYear(), viewMonth.getMonth()+1, 1); renderCalendar(); }; document.getElementById('exportBtn').onclick = exportData; document.getElementById('clearBtn').onclick = clearData; }
